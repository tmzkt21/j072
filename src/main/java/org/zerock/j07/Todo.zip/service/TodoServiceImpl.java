package org.zerock.j07.todo.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.zerock.j07.todo.dto.TodoDTO;
import org.zerock.j07.todo.repository.TodoRepository;

@Service
@Log4j2
@RequiredArgsConstructor            // ...1
public class TodoServiceImpl implements TodoService {

    private final TodoRepository todoRepository;            // ...2 1+2로 알아서 todoRepository를 주입해줌

    @Override
    public Long register(TodoDTO dto) {

        log.info(dto);

        return null;
    }
}
