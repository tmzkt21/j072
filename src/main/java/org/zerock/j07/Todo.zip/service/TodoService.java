package org.zerock.j07.todo.service;

import org.zerock.j07.todo.dto.TodoDTO;

public interface TodoService {

    Long register(TodoDTO dto);

}
